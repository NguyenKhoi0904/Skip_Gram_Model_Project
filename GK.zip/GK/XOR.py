import math
import csv

INPUT = [(0,0),(0,1),(1,0),(1,1)]
OUTPUT = [0,1,1,0]
epoch = 10000000

y_pred = 0.0
learning_rate = 0.1

def sigmoid(x:float)->float:
    return 1/(1 + math.exp(-x))

def equation(x1:float, x2:float, w1:float, w2:float, bias:float)->float:
    return x1*w1 + x2*w2 + bias

def loss_function(y:float, y_pred:float)->float:
    return -(y*math.log10(y_pred) + (1-y)*math.log10(1-y_pred))

def dL_dz3(y:float, y_pred:float)->float:
    return (y_pred - y)*y_pred*(1-y_pred)


def solve():
    #
    w11 = 0.2
    w12 = 0.4
    b1 = 0.1
    #
    w21 = 0.1
    w22 = 0.3
    b2 = 0.2
    #
    w31 = 0.15
    w32 = 0.35
    b3 = 0.3
    with open("nlp2.csv", "w", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=["y", "x1", "x2", "w11", "w12", "b1", "w21", "w22", "b2", "a1", "a2", "w31", "w32", "b3", "y_pred"])
        writer.writeheader()
        for _ in range(epoch+1):
            for i,v in enumerate(INPUT):
                z1 = equation(x1 = v[0], x2 = v[1], w1 = w11, w2 = w12, bias= b1)
                z2 = equation(x1 = v[0], x2 = v[1], w1 = w21, w2 = w22, bias= b2)
                a1 = sigmoid(z1)
                a2 = sigmoid(z2)
                z3 = equation(x1 = a1, x2 = a2, w1 = w31, w2 = w32, bias= b3)
                y_pred = sigmoid(z3)
                
                error = y_pred - OUTPUT[i]
                
                w11 = w11 - learning_rate*error*w31*a1*(1-a1)*v[0]
                w12 = w12 - learning_rate*error*w31*a1*(1-a1)*v[1]
                b1 = b1 - learning_rate*error*w31*a1*(1-a1)
                
                w21 = w21 - learning_rate*error*w32*a2*(1-a2)*v[0]
                w22 = w22 - learning_rate*error*w32*a2*(1-a2)*v[1]
                b2 = b2 - learning_rate*error*w32*a2*(1-a2)
                
                w31 = w31 - learning_rate*error*a1
                w32 = w32 - learning_rate*error*a2
                b3 = b3 - learning_rate*error
                
                writer.writerow({
                    "y": OUTPUT[i], "x1": v[0], "x2": v[1],
                    "w11": w11, "w12": w12, "b1": b1,
                    "w21": w21, "w22": w22, "b2": b2,
                    "a1": a1, "a2": a2, "w31": w31,
                    "w32": w32, "b3": b3, "y_pred": y_pred
                })
    
    ...

def main():
    solve()
    
if __name__ == "__main__":
    main()